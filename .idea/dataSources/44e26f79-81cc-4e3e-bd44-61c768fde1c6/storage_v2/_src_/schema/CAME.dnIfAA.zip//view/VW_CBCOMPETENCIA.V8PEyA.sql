create view VW_CBCOMPETENCIA as
  select competencia.codcom,CONCAT(CONCAT(COMPETENCIA.NOMCOM,' - '),AREA.ABRARE)AS COMABRE ,COMPETENCIA.NOMCOM,AREA.NOMARE,AREA.ABRARE,AREA.CODARE from competencia inner join area on competencia.codare = area.codare
/

