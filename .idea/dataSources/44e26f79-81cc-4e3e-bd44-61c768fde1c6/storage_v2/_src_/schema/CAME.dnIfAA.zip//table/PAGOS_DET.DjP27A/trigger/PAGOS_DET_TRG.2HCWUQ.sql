create trigger PAGOS_DET_TRG
  before insert
  on PAGOS_DET
  for each row
  BEGIN
SELECT PAGOS_DET_SEQ.NEXTVAL INTO :NEW.CODPAGDET FROM DUAL;
END;

/

