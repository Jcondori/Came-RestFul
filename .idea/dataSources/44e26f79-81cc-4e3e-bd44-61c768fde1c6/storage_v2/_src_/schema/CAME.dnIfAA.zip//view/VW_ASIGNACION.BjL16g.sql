create view VW_ASIGNACION as
  select prog_det.coddetprog,prog_det.estdetprog,PROGRAMA.CODPROG,PROGRAMA.ESTPROG ,CONCAT(CONCAT(PROGRAMA.NOMPROG,' - Gen : '),prog_det.GENDETPROG)As Programa from prog_det inner join PROGRAMA on programa.codprog = prog_det.CODPROG
/

