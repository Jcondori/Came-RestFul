create trigger PAGOS_TRG
  before insert
  on PAGOS
  for each row
  BEGIN
SELECT PAGOS_SEQ.NEXTVAL INTO :NEW.CODPAG FROM DUAL;
END;

/

