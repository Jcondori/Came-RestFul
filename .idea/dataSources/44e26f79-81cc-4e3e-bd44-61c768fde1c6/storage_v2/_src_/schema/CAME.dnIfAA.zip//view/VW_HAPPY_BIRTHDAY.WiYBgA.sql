create view VW_HAPPY_BIRTHDAY as
  SELECT
(UPPER(APEPER) ||', ' || INITCAP(NOMPER) ) AS NOMBRE,
IMGPER AS IMAGEN,
trunc((to_date((to_char(sysdate,'yyyy')||'-'||to_char(sysdate,'mm')||'-'||to_char(sysdate,'dd')),'yyyy-mm-dd')- FECHPER )/365) as edad,
'H' AS ESTADO
FROM PERSONA where  TO_CHAR(sysdate , 'dd/MM') = TO_CHAR(FECHPER,'dd/MM') UNION 
SELECT
(UPPER(APEPER) ||', ' || INITCAP(NOMPER) ) AS NOMBRE,
IMGPER AS IMAGEN,
trunc((to_date((to_char(sysdate,'yyyy')||'-'||to_char(sysdate,'mm')||'-'||to_char(sysdate,'dd')),'yyyy-mm-dd')- FECHPER )/365) as edad,
'M' AS ESTADO
FROM PERSONA where  TO_CHAR(sysdate + 1, 'dd/MM') = TO_CHAR(FECHPER,'dd/MM') UNION
SELECT
(UPPER(APEPER) ||', ' || INITCAP(NOMPER) ) AS NOMBRE,
IMGPER AS IMAGEN,
trunc((to_date((to_char(sysdate,'yyyy')||'-'||to_char(sysdate,'mm')||'-'||to_char(sysdate,'dd')),'yyyy-mm-dd')- FECHPER )/365) as edad,
'PM' AS ESTADO
FROM PERSONA where  TO_CHAR(sysdate + 2, 'dd/MM') = TO_CHAR(FECHPER,'dd/MM') ORDER BY ESTADO,NOMBRE
/

