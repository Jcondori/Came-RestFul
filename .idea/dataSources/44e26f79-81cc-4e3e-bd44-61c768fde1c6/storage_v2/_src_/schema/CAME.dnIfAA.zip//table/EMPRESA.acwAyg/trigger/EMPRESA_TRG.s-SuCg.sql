create trigger EMPRESA_TRG
  before insert
  on EMPRESA
  for each row
  BEGIN
SELECT EMPRESA_SEQ.NEXTVAL INTO :NEW.CODEMP FROM DUAL;
END;

/

