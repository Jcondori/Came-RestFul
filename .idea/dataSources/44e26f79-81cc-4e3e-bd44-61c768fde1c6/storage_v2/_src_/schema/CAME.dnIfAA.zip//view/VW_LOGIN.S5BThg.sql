create view VW_LOGIN as
  SELECT
    persona.CODPER,
    persona.DNIPER,
    persona.nomper,
    persona.apeper,
    persona.tipoper,
    asignacion.codasig,
    asignacion.coddetprog,
    persona.userper,
    persona.passper,
    F_PORCENTAJE_INASISTENCIAS(asignacion.codasig,asignacion.coddetprog) as Inasistencias,
    F_PROMFINAL_PROGRAMA(asignacion.codasig,asignacion.coddetprog) as Promedio
FROM
    persona
    LEFT JOIN asignacion ON persona.codper = asignacion.codper
WHERE
        estper LIKE 'A'
/

