create view VW_CBFASE as
  select fase.nomfase,fase.codfase,fase.ESTFASE,prog_det.coddetprog,PROG_DET.GENDETPROG from fase inner JOIN prog_det ON prog_det.coddetprog = fase.CODDETPROG
/

